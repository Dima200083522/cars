Vue.component('v-select',VueSelect.VueSelect);Vue.component('lch-time-picker',{template:'#lch-time-picker',data(){return{local_value:'',times:[],is_error:false,error_message:''}},props:{value:{type:String,required:true},stoplist:{type:Array,default:[]},select_date:{type:String,default:''},start_datetime:{type:Object,default:null},exclude_times:{type:Array,default:[]}},watch:{value(value){this.local_value=this.value
this.filter()},select_date(value){this.filter()},start_datetime:{handler:function(val,oldVal){this.filter()},deep:true}},methods:{opened(){Vue.nextTick(()=>{const active=this.$refs.select.$el.querySelector(".vs__dropdown-option--selected");if(active){var offsetTop=active.offsetTop-active.offsetHeight;active.parentElement.scrollTop=offsetTop>0?offsetTop:0}});},stringToStupid(time){var debris=time.split(':')
if(debris.length>=2){var hours=parseInt(debris[0])
var minutes=parseInt(debris[1])/60
return hours+minutes}
return 0},isAvailable(time_float,stopFrom,stopTo){for(var i=0;i<stopFrom.length;i++){if(time_float>stopFrom[i]){return false}}
for(var i=0;i<stopTo.length;i++){if(time_float<stopTo[i]){return false}}
if(this.start_datetime&&this.select_date){var mselect_date=moment(this.select_date,'DD/MM/YYYY')
var start_datetime=moment(this.start_datetime.date,'DD/MM/YYYY')
if(mselect_date.isSame(start_datetime,'day')){if(time_float-.5<this.stringToStupid(this.start_datetime.time)){return false}}}
return true},filter:function(){var times=[]
var stopFrom=[],stopTo=[]
var mselect_date=moment(this.select_date,'DD/MM/YYYY')
for(var i=0;i<this.stoplist.length;i++){if(mselect_date.isSame(this.stoplist[i].dateFrom,'day')){stopFrom.push(this.stoplist[i].timeFrom)}
if(mselect_date.isSame(this.stoplist[i].dateTo,'day')){stopTo.push(this.stoplist[i].timeTo)}}
var minutes=[':00',':30']
for(var h=0;h<=23;h++){for(var m=0;m<=1;m++){var time=h+minutes[m]
var time_float=h+m/2;if(!_.includes(this.exclude_times,time)){if(this.isAvailable(time_float,stopFrom,stopTo)){times.push(time)}}}}
this.times=times
if(times.includes(this.local_value)||!this.local_value){this.is_error=false
this.error_message=''}else{this.is_error=true
this.error_message=gettext('The selected time is not available')}},change(){this.$emit('input',this.local_value)}},computed:{errorText(){return gettext('Please, change time')}},mounted(){this.filter()},});;