function clearAnotherSliders(currentSlider){const $sliders=$('.slick-slide:not(:first-child).slick-current.slick-active').closest('.slick-slider')
$sliders.each((index,slider)=>{if(slider!=currentSlider){$(slider).slick('slickGoTo',0)}})}
function makeSlides(){const $slides=$('.item__slider:not(.slick-initialized)')
if($(window).width()>700){const $carItems=$('.car__item:not(.item-initialized)')
$slides.slick({dots:true,speed:1,infinite:false,arrows:false})
$carItems.each(function(){if($(this).find('.item__photo').length<=1){$(this).closest('.car__item').find('.slick-dots').hide()}else{let imgIndex=$(this).find('.item__photo').length-1
let imgSrc=$(this).find('.item__photo img').eq(imgIndex).attr('src');let $itemSlider=$(this).find('.item__slider')
let morePhotoCount=$itemSlider.data('photos-count')-$(this).find('.item__photo').length
if(morePhotoCount){$(this).find('.item__photo').last().append(`<div class="img__text">
            ${window.icons.camera}
            <span>${interpolate(ngettext('Plus %s photo', 'Plus %s photos', morePhotoCount), [morePhotoCount])}</span>
          </div>`)}
$(this).addClass('item-initialized')}})}
$slides.find('.slick-dots li').mousemove(function(){const $li=$(this)
const $slider=$li.closest('.slick-slider')
$($slider).slick('slickGoTo',$li.index())
if($slider.length){clearAnotherSliders($slider[0])}})
$slides.mouseleave(function(){$(this).closest('.slick-slider').slick('slickGoTo',0)})
$slides.closest('.car__item').mouseenter(function(){const $slider=$(this).find('.slick-slider')
if($slider.length){clearAnotherSliders($slider[0])}})
$slides.closest('.car__item').mouseleave(function(){clearAnotherSliders()})};$(document).ready(function(){let msgModal=$('#small-dialog');let messageForm=$('#send-msg-to-company');let textMsgInput=messageForm.find('textarea');let textErrors=$('#msg-modal-text-errors');let formErrors=$('#msg-modal-errors');let textarea=$("#msg-modal-textarea");let sendMsgBtn=$("#msg-modal-send-btn");messageForm.on("submit",function(e){e.preventDefault();e.stopPropagation();sendMsgBtn.prop('disabled',true);textErrors.empty();formErrors.empty();textarea.removeClass('error');let data=messageForm.serializeArray();let company=$(this).data('company');if(company)data.push({name:'company',value:company});let user=$(this).data('user');if(user)data.push({name:'user',value:user});$.ajax({url:this.action,method:'put',data:data,dataType:'json',}).done(function(response){clearForm();alert('Message has been sent');sendMsgBtn.prop('disabled',false);}).error(function(response){let errors=response.responseJSON;sendMsgBtn.prop('disabled',false);for(let errField in errors){if(errField==='text'){textarea.addClass('error');errors[errField].forEach(function(error){textErrors.append("<li class='error'>"+error+"</li>")})}
else{formErrors.append("<li class='error'><b>"+errField+'</b>: '+errors[errField]+"</li>")}}});});function clearForm(){console.log('clear form...');$('.popup').removeClass('popup__open')
messageForm[0].reset();textErrors.empty();formErrors.empty();}});;