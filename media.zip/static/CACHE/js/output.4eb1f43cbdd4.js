Vue.component('lch-date-picker',{template:'#lch-date-picker',data(){return{local_value:'',is_error:false,error_message:'',basestop_limit:null}},props:{value:{type:String,required:true},stoplist:{type:Array,default:[]},basestop:{type:String,default:''},finish_date:{type:String,default:''},lang:{type:String,default:'en'},weekends:{type:Array,default:[]}},watch:{value(value){this.local_value=moment(value,'DD/MM/YYYY')},finish_date(value){this.markErrors()},basestop(value){this.basestop_limit=null
var basestop=moment(this.basestop,'DD/MM/YYYY')
for(var i=0;i<this.stoplist.length;i++){if(basestop.isBefore(this.stoplist[i].dateFrom,'day')){if(!this.basestop_limit){this.basestop_limit=moment(this.stoplist[i].dateFrom)}else{if(this.basestop_limit.isBefore(this.stoplist[i].dateFrom,'day')){this.basestop_limit=moment(this.stoplist[i].dateFrom)}}}}
if(basestop.isAfter(this.local_value,'day')){this.local_value=basestop.add(1,'days')
this.change()}
this.markErrors()}},methods:{disabledDate(time){var mtime=moment(time)
if(_.includes(this.weekends,parseInt(mtime.format('d')))){return true}
var basestop
if(this.basestop){basestop=moment(this.basestop,'DD/MM/YYYY')
if(mtime.isBefore(basestop,'day')){return true}
if(this.basestop_limit){if(mtime.isAfter(this.basestop_limit,'day')){return true}}}
for(var i=0;i<this.stoplist.length;i++){var is_contain=mtime.isBetween(this.stoplist[i].dateFrom,this.stoplist[i].dateTo,'days');if(is_contain)return true;}
return false;},change(){this.markErrors()
this.$emit('input',moment(this.local_value).format('DD/MM/YYYY'))},markErrors(){this.is_error=false
this.error_message=''
if(this.finish_date){var finish_date=moment(this.finish_date,'DD/MM/YYYY')
if(finish_date.isBefore(this.local_value,'day')){this.is_error=true
this.error_message=gettext('Pickup date must be less than return date')}}
if(this.basestop_limit){if(this.basestop_limit.isBefore(this.local_value,'day')){this.is_error=true
this.error_message=gettext('Within the selected period the machine is busy')}}}},computed:{language(){const CUSTOM_LOCALES=['pl']
if([CUSTOM_LOCALES.includes(this.lang)]&&DATEPICKER_OPTIONS.locale){const locale={days:DATEPICKER_OPTIONS.locale.daysMin.slice(),months:DATEPICKER_OPTIONS.locale.monthsShort.slice()}
return locale}
return this.lang}},mounted(){this.local_value=moment(this.value,'DD/MM/YYYY')},});;