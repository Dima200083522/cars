if (!window.icons) {
  window.icons = {}
}
