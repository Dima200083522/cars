// TODO: объединить js/search_form_default.js и redesign/js/search.js
$(document).ready(function () {
    window.SearchInited = {
        done: false,
        pickupDate: false,
        returnDate: false,
        init: function() {
            if (window.SearchInited.pickupDate && window.SearchInited.returnDate) {
                window.SearchInited.done = true
                window.reloadCars();
            } else {
                setTimeout(window.SearchInited.init, 50);
            }
        }
    }
    window.reloadCars = function () {
        if (window.app && window.app.lazyLoadCars) {
            window.app.lazyLoadCars()
        }
    }

    let urlParams = new URLSearchParams(document.location.search.substring(1));
    let searchForm = $('#top-search-form');
    let date = moment(new Date());
    let pickupDateInput = $('input[name="pickup_date"]');
    let returnDateInput = $('input[name="return_date"]');
    let pdPicker = pickupDateInput.data('datepicker');
    let rdPicker = returnDateInput.data('datepicker');
    let pickupTimeInput = $('input[name="pickup_time"]');
    let returnTimeInput = $('input[name="return_time"]');

    var params = {
        pickup_date: urlParams.get('pickup_date'),
        return_date: urlParams.get('return_date'),
        pickup_place: urlParams.get('pickup_place'),
        return_place: urlParams.get('return_place'),
        pickup_time: urlParams.get('pickup_time'),
        return_time: urlParams.get('return_time'),
    }

    pickupDateInput.on('change', function () {
        if (pdPicker.selectedDates.length) {
            rdPicker.update('minDate', pdPicker.selectedDates[0]);

            if (window.SearchInited.done) {
                let newReturnDate = new Date(pdPicker.selectedDates[0]);
                newReturnDate.setDate(newReturnDate.getDate() + 7);
                rdPicker.selectDate(new Date(newReturnDate));
                daysCount()
            }
        }
    });
    returnDateInput.on('change', function () {
        if (rdPicker.selectedDates.length) {
            daysCount()
        }
    })

    if (params.pickup_date) date = moment(params.pickup_date, 'DD/MM/YYYY'); else date.add(10, 'days');
    pdPicker.selectDate(new Date(date._d)).then(function() { window.SearchInited.pickupDate = true });
    if (params.return_date) date = moment(params.return_date, 'DD/MM/YYYY'); else date.add(7, 'days');
    rdPicker.selectDate(new Date(date._d)).then(function() { window.SearchInited.returnDate = true });

    let pickupPlace = $('select[name="pickup_place"]');
    let returnPlace = $('select[name="return_place"]');
    pickupPlace.on('change', function(e) {
        if (window.SearchInited.done) {
            const selected_country = pickupPlace.find('option[value=' + pickupPlace.val() + ']')
            const return_option = returnPlace.find('option[value=' + pickupPlace.val() + ']')
            if (selected_country.length && !return_option.length) {
                returnPlace.html(selected_country[0].outerHTML);
            }
            returnPlace.val(pickupPlace.val());
            returnPlace.trigger('change');
            setFormUrl();
            window.reloadCars();
        }
    });

    returnPlace.on('change', function(e) {
        window.reloadCars();
    })

    if (params.pickup_place) {
        pickupPlace.val(params.pickup_place);
        pickupPlace.trigger('change');
    }    
    if (params.return_place) {
        returnPlace.val(params.return_place);
        returnPlace.trigger('change');
    }

    pickupTimeInput.on('change', function() {
        daysCount()
        window.reloadCars()
    });
    returnTimeInput.on('change', function() {
        daysCount()
        window.reloadCars()
    });

    if (params.pickup_time) {
        const time = moment(params.pickup_time, 'HH:mm').format('H:mm')
        pickupTimeInput.setVlasSelect(time)
    }
    if (params.return_time) {
        const time = moment(params.return_time, 'HH:mm').format('H:mm')
        returnTimeInput.setVlasSelect(time)
    }

    function daysCount() {
        const daysBadge = $('#days-badge .count');
        const daysBadgeUnit = $('#days-badge .d-unit');
        const from = moment(pdPicker.$el.value + ' ' + pickupTimeInput.val(), 'DD/MM/YYYY HH:mm')
        const to = moment(rdPicker.$el.value + ' ' + returnTimeInput.val(), 'DD/MM/YYYY HH:mm')
        const days = Math.ceil(to.diff(from, 'minutes') / (24 * 60))
        daysBadge.text(days);
        daysBadgeUnit.text(dayWithNumber(days));
        daysBadge.addClass('rotate-x')
        setTimeout(function () {daysBadge.removeClass('rotate-x'); }, 700);
        if (window.SearchInited.done) {
            window.reloadCars();
        }
    }

    setFormUrl();

    function setFormUrl() {
        if (pickupPlace.val()) {
            let option = pickupPlace.find('option[value=' + pickupPlace.val() + ']');
            let country_slug = searchForm.data('countrySlug');
            // if (!country_slug) {
            //     let optgroup = option.closest('optgroup');
            //     country_slug = optgroup.data('countrySlug');
            // }
            if (!country_slug) {
                country_slug = option.attr('data-country-slug');
            }
            searchForm.attr(
                'action',
                '/' + lang + '/' + country_slug + '/'
            );
        }
    }

    window.SearchInited.init()
});