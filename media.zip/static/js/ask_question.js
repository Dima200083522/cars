$(document).ready(function () {
    let messageForm = $('#ask-question');
    let textMsgInput = messageForm.find('textarea');

    messageForm.on("submit", function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (textMsgInput.val().length > 2) {
            let data = messageForm.serializeArray();
            if (typeof country_id !== 'undefined') {
                data.push({ name: 'country_id', value: country_id })
            }
            $.ajax({
                url: messageForm.attr('action'),
                method: 'post',
                data: data,
                dataType: 'json',
            })
            .done(function (response) {
                if ('error' in response) {
                    alert(gettext(`Error! ${response.error}`));
                    console.log('Error! ' + response.error);
                } else if ('message' in response) {
                    messageForm.find('.notes__item')
                                .removeClass('hidden')
                                .css('display', 'block')
                                .find('p')
                                .text(response.message)
                    clearForm();
                } else {
                    messageForm.find('.notes__item')
                                .removeClass('hidden')
                                .css('display', 'block')
                                .find('p')
                                .text('Your question has been sent')
                    clearForm();
                }
            })
            .fail(function (response) {
                alert(gettext('Error! Question have not been sent.'));
                console.log(response.responseText);
            });
        } else {
            alert('Question is too short!');
        }
    });

    function clearForm() {
        messageForm[0].reset();
    }
});