$(document).ready(function() {
  $('.banner__reviews').on('click', function() {
    $('.page-index__reviews')[0].scrollIntoView({ block: 'center',  behavior: 'smooth' });
  })
})
