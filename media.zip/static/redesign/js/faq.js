$(document).ready(function() {
  const $template = $(`<div class="inner__bottom">
  <span>${gettext('Find this useful?')}</span>
  <div class="like">
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M5.83061 9.06682V21H17.1347C18.286 21 19.2773 20.197 19.5031 19.0814L20.9523 11.9215C21.2512 10.4447 20.108 9.06682 18.5839 9.06682H13.0765L16.006 4.72477C16.9325 3.35153 16.2025 1.48582 14.5821 1.08553L14.5247 1.07134C13.6371 0.852088 12.7004 1.14715 12.1051 1.83351L5.83061 9.06682Z"
      fill="" />
      <path d="M5.83061 9.06682H1V21H5.83061M5.83061 9.06682V21M5.83061 9.06682L12.1051 1.83351C12.7004 1.14715 13.6371 0.852088 14.5247 1.07134L14.5821 1.08553C16.2025 1.48582 16.9325 3.35153 16.006 4.72477L13.0765 9.06682H18.5839C20.108 9.06682 21.2512 10.4447 20.9523 11.9215L19.5031 19.0814C19.2773 20.197 18.286 21 17.1347 21H5.83061"
      stroke="#059902" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    </svg><span>${gettext('Yes')}</span>
  </div>
  <div class="dislike">
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M5.83061 12.9332V1H17.1347C18.286 1 19.2773 1.80301 19.5031 2.91858L20.9523 10.0785C21.2512 11.5553 20.108 12.9332 18.5839 12.9332H13.0765L16.006 17.2752C16.9325 18.6485 16.2025 20.5142 14.5821 20.9145L14.5247 20.9287C13.6371 21.1479 12.7004 20.8529 12.1051 20.1665L5.83061 12.9332Z"
      fill="#FF002F" />
      <path d="M5.83061 12.9332H1V1H5.83061M5.83061 12.9332V1M5.83061 12.9332L12.1051 20.1665C12.7004 20.8529 13.6371 21.1479 14.5247 20.9287L14.5821 20.9145C16.2025 20.5142 16.9325 18.6485 16.006 17.2752L13.0765 12.9332H18.5839C20.108 12.9332 21.2512 11.5553 20.9523 10.0785L19.5031 2.91858C19.2773 1.80301 18.286 1 17.1347 1H5.83061"
      stroke="#DF0029" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    </svg><span>${gettext('No')}</span>
  </div>
</div>
`)

	$('.faq .akkordeon__head').on('click', function() {
		const $this = $(this)
		const $inner = $this.parent('.akkordeon').find('.akkordeon__inner')
		if (!$inner.find('.inner__bottom').length) {
			$inner.append($template.clone())
			$inner.find('.like').click(function (e) {
				setTimeout(() => {
					$(this).parent().text(gettext('Thank you!'))
				}, 200);
				e.stopPropagation();
				e.preventDefault();
			})
			$inner.find('.dislike').click(function (e) {
				setTimeout(() => {
					$(this).parent().text(gettext('Thank you!'))
				}, 200);
				e.stopPropagation();
				e.preventDefault();
			})
		}
	})

})
